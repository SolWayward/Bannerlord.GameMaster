## Final Recommended Architecture

### Directory and Namespace Structure

```
Console/Common/
├── Execution/                                    # Namespace: Console.Common.Execution
│   ├── CommandExecutor.cs                        # The Cmd class
│   ├── CommandErrorHandler.cs                    # Centralized exception handling
│   └── CommandLogger.cs                          # File-based logging (existing, moved)
│
├── Parsing/                                      # Namespace: Console.Common.Parsing
│   ├── ArgumentParser.cs                         # ParseQuotedArguments, JoinRemainingArgs
│   ├── ParsedArguments.cs                        # ParsedArguments class
│   ├── ArgumentDefinition.cs                     # ArgumentDefinition class
│   ├── FlagParser.cs                             # Culture/gender flag parsing (existing, moved)
│   └── QueryArgumentParser.cs                    # Query argument parsing (existing, moved)
│
├── Validation/                                   # Namespace: Console.Common.Validation
│   └── CommandValidator.cs                       # All validation (existing + campaign state)
│
├── EntityFinding/                                # Namespace: Console.Common.EntityFinding
│   └── EntityFinder.cs                           # All FindSingleXxx methods
│
├── Formatting/                                   # Namespace: Console.Common.Formatting
│   ├── MessageFormatter.cs                       # FormatSuccessMessage, FormatErrorMessage
│   └── ColumnFormatter.cs                        # Column alignment (existing, moved)
│
└── CommandResult.cs                              # Keep in Console.Common (simple type)
```

### Files to Delete
- [`ErrorLogger.cs`](Bannerlord.GameMaster/Console/Common/ErrorLogger.cs:1) - Replaced by `CommandErrorHandler.cs`
- [`CommandBase.cs`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:1) - Split into multiple files (no facade needed since clean break)

---

## Detailed File Specifications

### 1. CommandErrorHandler.cs (New)

**Location**: `Console/Common/Execution/CommandErrorHandler.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Execution`

```csharp
namespace Bannerlord.GameMaster.Console.Common.Execution;

using System;
using System.Text;

/// <summary>
/// Centralized exception handling for all console commands.
/// Logs full details to RGL log file, returns minimal message for console display.
/// </summary>
public static class CommandErrorHandler
{
    private const string PREFIX = "[BLGM] Command Error:";

    /// <summary>
    /// Handles an exception from command execution.
    /// Writes command name, exception message, and stack trace to RGL log file.
    /// Returns only the prefix and exception message for console display.
    /// </summary>
    /// <param name="commandName">The full command that was executed (e.g., "gm.hero.create_hero count:5")</param>
    /// <param name="ex">The exception that occurred</param>
    /// <returns>Error message for console display (prefix + exception message only)</returns>
    public static string HandleException(string commandName, Exception ex)
    {
        // MARK: Build RGL log message (full details)
        StringBuilder logBuilder = new();
        logBuilder.AppendLine(PREFIX);
        logBuilder.AppendLine($"Command: {commandName}");
        logBuilder.AppendLine($"Exception: {ex.Message}");
        logBuilder.AppendLine("Stack Trace:");
        logBuilder.AppendLine(ex.StackTrace);
        
        // Handle inner exceptions
        Exception inner = ex.InnerException;
        while (inner != null)
        {
            logBuilder.AppendLine($"Inner Exception: {inner.Message}");
            logBuilder.AppendLine(inner.StackTrace);
            inner = inner.InnerException;
        }

        // Write to RGL log file
        TaleWorlds.Library.Debug.Print(logBuilder.ToString());

        // MARK: Return console message (minimal - prefix and message only)
        return $"{PREFIX} {ex.Message}\n";
    }
}
```

### 2. CommandExecutor.cs (Extracted from Cmd)

**Location**: `Console/Common/Execution/CommandExecutor.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Execution`

```csharp
namespace Bannerlord.GameMaster.Console.Common.Execution;

using System;
using System.Collections.Generic;
using Bannerlord.GameMaster.Console.Common.Parsing;

/// <summary>
/// Executes console commands with automatic logging and error handling.
/// All command methods should use this as their entry point.
/// </summary>
public static class CommandExecutor
{
    /// <summary>
    /// Execute command with automatic logging, quote parsing, and centralized error handling.
    /// </summary>
    public static string Run(List<string> args, Func<string> action)
    {
        // Parse quoted arguments before passing to action
        List<string> parsedArgs = ArgumentParser.ParseQuotedArguments(args);
        
        // Replace the args list contents with parsed args
        if (args != null && parsedArgs != null)
        {
            args.Clear();
            args.AddRange(parsedArgs);
        }

        string commandName = GetCallingCommandName(parsedArgs);

        try
        {
            string result = action();
            
            if (CommandLogger.IsEnabled)
            {
                bool isSuccess = !result.StartsWith("Error:", StringComparison.OrdinalIgnoreCase);
                CommandLogger.LogCommand(commandName, result, isSuccess);
            }
            
            return result;
        }
        catch (Exception ex)
        {
            // Centralized error handling - logs to RGL, returns minimal message
            string errorResult = CommandErrorHandler.HandleException(commandName, ex);

            if (CommandLogger.IsEnabled)
            {
                CommandLogger.LogCommand(commandName, errorResult, false);
            }
            
            return errorResult;
        }
    }

    /// <summary>
    /// Execute command with automatic logging using CommandResult return type.
    /// </summary>
    public static CommandResult Run(List<string> args, Func<CommandResult> action)
    {
        List<string> parsedArgs = ArgumentParser.ParseQuotedArguments(args);
        
        if (args != null && parsedArgs != null)
        {
            args.Clear();
            args.AddRange(parsedArgs);
        }
        
        string commandName = GetCallingCommandName(parsedArgs);
        
        try
        {
            CommandResult result = action();
            
            if (CommandLogger.IsEnabled)
            {
                CommandLogger.LogCommand(commandName, result.Message, result.IsSuccess);
            }
            
            return result;
        }
        catch (Exception ex)
        {
            string errorMessage = CommandErrorHandler.HandleException(commandName, ex);

            if (CommandLogger.IsEnabled)
            {
                CommandLogger.LogCommand(commandName, errorMessage, false);
            }
            
            return CommandResult.Error(ex.Message);
        }
    }

    /// <summary>
    /// Executes an action safely with consistent error handling (for use outside Cmd.Run)
    /// </summary>
    public static string ExecuteWithErrorHandling(Func<string> action, string commandContext = "unknown")
    {
        try
        {
            return action();
        }
        catch (Exception ex)
        {
            return CommandErrorHandler.HandleException(commandContext, ex);
        }
    }

    // MARK: Private helper to get command name from reflection
    private static string GetCallingCommandName(List<string> args)
    {
        try
        {
            System.Diagnostics.StackTrace stackTrace = new();
            System.Reflection.MethodBase callingMethod = stackTrace.GetFrame(2)?.GetMethod();
            
            if (callingMethod != null)
            {
                object[] attributes = callingMethod.GetCustomAttributes(false);
                foreach (object attr in attributes)
                {
                    Type attrType = attr.GetType();
                    if (attrType.Name == "CommandLineArgumentFunctionAttribute")
                    {
                        System.Reflection.PropertyInfo nameProperty = attrType.GetProperty("Name");
                        System.Reflection.PropertyInfo parentProperty = attrType.GetProperty("ParentCommandName");
                        
                        if (nameProperty != null && parentProperty != null)
                        {
                            string name = nameProperty.GetValue(attr) as string;
                            string parent = parentProperty.GetValue(attr) as string;
                            
                            string commandName = string.IsNullOrEmpty(parent) ? name : $"{parent}.{name}";
                            
                            if (args != null && args.Count > 0)
                            {
                                commandName += " " + string.Join(" ", args);
                            }
                            
                            return commandName;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            TaleWorlds.Library.Debug.Print($"[BLGM] Failed to get calling command name: {ex.Message}");
        }
        
        if (args != null && args.Count > 0)
        {
            return "gm.command " + string.Join(" ", args);
        }
        
        return "gm.command";
    }
}

/// <summary>
/// Short alias for CommandExecutor for backward compatibility and convenience.
/// Usage: return Cmd.Run(args, () => { /* your logic */ });
/// </summary>
public static class Cmd
{
    public static string Run(List<string> args, Func<string> action) 
        => CommandExecutor.Run(args, action);
    
    public static CommandResult Run(List<string> args, Func<CommandResult> action) 
        => CommandExecutor.Run(args, action);
}
```

---

### 3. ArgumentParser.cs (Extracted)

**Location**: `Console/Common/Parsing/ArgumentParser.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Parsing`

Contains the static quote parsing methods extracted from [`CommandBase.cs`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:466):
- `ParseQuotedArguments()` (lines 466-581)
- `JoinRemainingArgs()` (lines 588-593)
- `GetArgument()` (lines 600-608)
- `ParseArguments()` (lines 839-846)

### 4. ParsedArguments.cs (Extracted)

**Location**: `Console/Common/Parsing/ParsedArguments.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Parsing`

The [`ParsedArguments`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:640) class (lines 640-833) extracted to its own file.

### 5. ArgumentDefinition.cs (Extracted)

**Location**: `Console/Common/Parsing/ArgumentDefinition.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Parsing`

The [`ArgumentDefinition`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:618) class (lines 618-633) extracted to its own file.

### 6. EntityFinder.cs (Extracted)

**Location**: `Console/Common/EntityFinding/EntityFinder.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.EntityFinding`

Contains all the `FindSingleXxx` methods and `ResolveMultipleMatches`:
- [`FindSingleHero()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:29) (lines 29-58)
- [`FindSingleClan()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:64) (lines 64-82)
- [`FindSingleKingdom()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:87) (lines 87-105)
- [`FindSingleItem()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:110) (lines 110-128)
- [`FindSingleTroop()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:133) (lines 133-151)
- [`FindSingleCharacterObject()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:157) (lines 157-175)
- [`FindSingleSettlement()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:180) (lines 180-198)
- [`ResolveMultipleMatches()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:212) (lines 212-381)

### 7. CommandValidator.cs (Enhanced)

**Location**: `Console/Common/Validation/CommandValidator.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Validation`

Existing [`CommandValidator.cs`](Bannerlord.GameMaster/Console/Common/CommandValidator.cs:1) plus the validation methods from CommandBase:
- [`ValidateCampaignState()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:390) (lines 390-410)
- [`ValidateNoSettlementClaimantDecisionsPending()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:413) (lines 413-434)
- [`ValidateArgumentCount()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:439) (lines 439-448)

### 8. MessageFormatter.cs (New)

**Location**: `Console/Common/Formatting/MessageFormatter.cs`  
**Namespace**: `Bannerlord.GameMaster.Console.Common.Formatting`

```csharp
namespace Bannerlord.GameMaster.Console.Common.Formatting;

/// <summary>
/// Provides consistent message formatting for command output.
/// </summary>
public static class MessageFormatter
{
    /// <summary>
    /// Formats a success message with consistent styling.
    /// </summary>
    public static string FormatSuccessMessage(string message)
    {
        return $"Success: {message}\n";
    }

    /// <summary>
    /// Formats an error message with consistent styling.
    /// </summary>
    public static string FormatErrorMessage(string message)
    {
        return $"Error: {message}\n";
    }
}
```

---

## Data Flow Diagram

```mermaid
flowchart TD
    subgraph "Command Execution Flow"
        A[User Types Command] --> B["Cmd.Run(args, action)"]
        B --> C["ArgumentParser.ParseQuotedArguments()"]
        C --> D[Execute action()]
        
        D --> E{Exception?}
        E -->|No| F[Return result string]
        E -->|Yes| G["CommandErrorHandler.HandleException()"]
        
        G --> H["Debug.Print() to RGL Log<br/>[BLGM] Command Error:<br/>Command: gm.hero.create...<br/>Exception: message<br/>Stack Trace: ..."]
        G --> I["Return to Console<br/>[BLGM] Command Error: message"]
        
        F --> J{CommandLogger.IsEnabled?}
        I --> J
        J -->|Yes| K["CommandLogger.LogCommand()"]
        J -->|No| L[Return to Game Console]
        K --> L
    end
    
    style G fill:#FF6B6B
    style H fill:#FFE66D
    style I fill:#4ECDC4
```

---

## Import Changes Required in Commands

Commands will need to update their imports. Example for a typical command file:

**Before:**
```csharp
using Bannerlord.GameMaster.Console.Common;
```

**After:**
```csharp
using Bannerlord.GameMaster.Console.Common;                    // CommandResult
using Bannerlord.GameMaster.Console.Common.Execution;          // Cmd, CommandExecutor
using Bannerlord.GameMaster.Console.Common.Parsing;            // ArgumentParser, ParsedArguments
using Bannerlord.GameMaster.Console.Common.Validation;         // CommandValidator
using Bannerlord.GameMaster.Console.Common.EntityFinding;      // EntityFinder
using Bannerlord.GameMaster.Console.Common.Formatting;         // MessageFormatter
```

Or use a more concise approach with aliases:
```csharp
using Bannerlord.GameMaster.Console.Common.Execution;
using Bannerlord.GameMaster.Console.Common.Parsing;
using Bannerlord.GameMaster.Console.Common.Validation;
using Bannerlord.GameMaster.Console.Common.EntityFinding;
using Bannerlord.GameMaster.Console.Common.Formatting;
```

---

## Summary Table

| Current File | Action | New Location(s) |
|--------------|--------|-----------------|
| `CommandBase.cs` (1061 lines) | **Split** | `ArgumentParser.cs`, `ParsedArguments.cs`, `ArgumentDefinition.cs`, `EntityFinder.cs`, `MessageFormatter.cs` |
| `ErrorLogger.cs` (21 lines) | **Delete/Replace** | `CommandErrorHandler.cs` |
| `CommandLogger.cs` (255 lines) | **Move** | `Execution/CommandLogger.cs` |
| `CommandValidator.cs` (189 lines) | **Move + Enhance** | `Validation/CommandValidator.cs` (add campaign validation) |
| `CommandResult.cs` (37 lines) | **Keep** | `Console/Common/CommandResult.cs` |
| `FlagParser.cs` (91 lines) | **Move** | `Parsing/FlagParser.cs` |
| `QueryArgumentParser.cs` (47 lines) | **Move** | `Parsing/QueryArgumentParser.cs` |
| `ColumnFormatter.cs` (129 lines) | **Move** | `Formatting/ColumnFormatter.cs` |
| *(new)* | **Create** | `Execution/CommandExecutor.cs`, `Execution/CommandErrorHandler.cs`, `Parsing/ArgumentDefinition.cs`, `Formatting/MessageFormatter.cs` |

---

## RGL Log Output Example

When a command throws an exception, the RGL log file will contain:

```
[BLGM] Command Error:
Command: gm.hero.create_hero count:5 culture:vlandia
Exception: Object reference not set to an instance of an object
Stack Trace:
   at Bannerlord.GameMaster.Heroes.HeroManager.CreateHero(CultureObject culture, Int32 count) in HeroManager.cs:line 145
   at Bannerlord.GameMaster.Console.HeroCommands.HeroGenerationCommands.CreateHero(List`1 args) in HeroGenerationCommands.cs:line 87
   at Bannerlord.GameMaster.Console.Common.Execution.CommandExecutor.Run(List`1 args, Func`1 action) in CommandExecutor.cs:line 42
```

And the game console will only show:
```
[BLGM] Command Error: Object reference not set to an instance of an object
```

## Centralized Error Handling and Console/Common Refactoring Plan

### Centralized Error Handling Solution

The new [`CommandErrorHandler`](Bannerlord.GameMaster/Console/Common/Execution/CommandErrorHandler.cs) class provides:

- **RGL Log Output** (full details): `[BLGM] Command Error:` prefix, command name, exception message, and stack trace
- **Console Output** (minimal): Only `[BLGM] Command Error: {exception.Message}`

All exceptions flow through [`Cmd.Run()`](Bannerlord.GameMaster/Console/Common/CommandBase.cs:896) which calls `CommandErrorHandler.HandleException()`, ensuring consistent handling across all commands.

### Refactored Directory Structure

```
Console/Common/
├── Execution/                     # Console.Common.Execution
│   ├── CommandExecutor.cs         # Cmd class + ExecuteWithErrorHandling
│   ├── CommandErrorHandler.cs     # Centralized exception handling (NEW)
│   └── CommandLogger.cs           # File logging (moved)
├── Parsing/                       # Console.Common.Parsing
│   ├── ArgumentParser.cs          # ParseQuotedArguments, ParseArguments
│   ├── ParsedArguments.cs         # ParsedArguments class
│   ├── ArgumentDefinition.cs      # ArgumentDefinition class
│   ├── FlagParser.cs              # Culture/gender parsing (moved)
│   └── QueryArgumentParser.cs     # Query parsing (moved)
├── Validation/                    # Console.Common.Validation
│   └── CommandValidator.cs        # All validation methods (enhanced)
├── EntityFinding/                 # Console.Common.EntityFinding
│   └── EntityFinder.cs            # All FindSingleXxx methods
├── Formatting/                    # Console.Common.Formatting
│   ├── MessageFormatter.cs        # FormatSuccessMessage/ErrorMessage (NEW)
│   └── ColumnFormatter.cs         # Column alignment (moved)
└── CommandResult.cs               # Keep in Console.Common
```


## Console/Common Refactoring Complete

The Console/Common directory has been successfully refactored from a monolithic structure into focused, single-responsibility components. The ~1061 line "God Class" [`CommandBase.cs`](Bannerlord.GameMaster/Console/Common/CommandBase.cs) has been eliminated.

### New Directory Structure

**Console/Common/** now contains:
- [`CommandResult.cs`](Bannerlord.GameMaster/Console/Common/CommandResult.cs) - Simple result type (retained)
- **EntityFinding/** - Entity finder methods
- **Execution/** - Command execution, error handling, and logging  
- **Formatting/** - Message and output formatting
- **Parsing/** - Argument parsing infrastructure
- **Validation/** - Command validation logic

### Completed Phases

**Phase 1: Execution Directory**
- Created [`CommandErrorHandler.cs`](Bannerlord.GameMaster/Console/Common/Execution/CommandErrorHandler.cs) - Centralized exception handling with RGL logging
- Created [`CommandExecutor.cs`](Bannerlord.GameMaster/Console/Common/Execution/CommandExecutor.cs) - Cmd class with `Run()` methods

**Phase 2: Parsing Directory**  
- Created [`ArgumentParser.cs`](Bannerlord.GameMaster/Console/Common/Parsing/ArgumentParser.cs) - Static parsing methods
- Created [`ParsedArguments.cs`](Bannerlord.GameMaster/Console/Common/Parsing/ParsedArguments.cs) - Named/positional argument handling
- Created [`ArgumentDefinition.cs`](Bannerlord.GameMaster/Console/Common/Parsing/ArgumentDefinition.cs) - Argument metadata

**Phase 3: Additional Parsing Classes**
- Moved [`FlagParser.cs`](Bannerlord.GameMaster/Console/Common/Parsing/FlagParser.cs) - Culture/gender flag parsing
- Moved [`QueryArgumentParser.cs`](Bannerlord.GameMaster/Console/Common/Parsing/QueryArgumentParser.cs) - Query argument parsing

**Phase 4: EntityFinding Directory**
- Created [`EntityFinder.cs`](Bannerlord.GameMaster/Console/Common/EntityFinding/EntityFinder.cs) - All FindSingleXxx methods (~320 lines)

**Phase 5: Formatting Directory**
- Created [`MessageFormatter.cs`](Bannerlord.GameMaster/Console/Common/Formatting/MessageFormatter.cs) - Success/error formatting
- Moved [`ColumnFormatter.cs`](Bannerlord.GameMaster/Console/Common/Formatting/ColumnFormatter.cs) - Column-aligned output

**Phase 6: Validation Directory**
- Moved and enhanced [`CommandValidator.cs`](Bannerlord.GameMaster/Console/Common/Validation/CommandValidator.cs) - All validation methods

**Phase 7: Move CommandLogger**
- Moved [`CommandLogger.cs`](Bannerlord.GameMaster/Console/Common/Execution/CommandLogger.cs) to Execution directory

**Phase 8: Cleanup**
- Deleted obsolete `ErrorLogger.cs` (replaced by CommandErrorHandler)
- Deleted obsolete `CommandBase.cs` (split into focused files)

### Centralized Error Handling

The new [`CommandErrorHandler.HandleException()`](Bannerlord.GameMaster/Console/Common/Execution/CommandErrorHandler.cs) provides:
- **RGL Log Output**: `[BLGM] Command Error:` prefix, command name, exception message, stack trace
- **Console Output**: Only `[BLGM] Command Error: {message}` (no stack trace in console)

### Import Mapping for Command Updates

When updating the 31 command files, use these new imports:

```csharp
using Bannerlord.GameMaster.Console.Common;                    // CommandResult
using Bannerlord.GameMaster.Console.Common.Execution;          // Cmd, CommandExecutor, CommandLogger, CommandErrorHandler  
using Bannerlord.GameMaster.Console.Common.Parsing;            // ArgumentParser, ParsedArguments, ArgumentDefinition, FlagParser, QueryArgumentParser
using Bannerlord.GameMaster.Console.Common.Validation;         // CommandValidator
using Bannerlord.GameMaster.Console.Common.EntityFinding;      // EntityFinder
using Bannerlord.GameMaster.Console.Common.Formatting;         // MessageFormatter, ColumnFormatter
```

**Class Name Changes:**
- `CommandBase.FindSingleHero()` → `EntityFinder.FindSingleHero()`
- `CommandBase.FindSingleClan()` → `EntityFinder.FindSingleClan()`  
- `CommandBase.FindSingleKingdom()` → `EntityFinder.FindSingleKingdom()`
- `CommandBase.FindSingleItem()` → `EntityFinder.FindSingleItem()`
- `CommandBase.FindSingleTroop()` → `EntityFinder.FindSingleTroop()`
- `CommandBase.FindSingleCharacterObject()` → `EntityFinder.FindSingleCharacterObject()`
- `CommandBase.FindSingleSettlement()` → `EntityFinder.FindSingleSettlement()`
- `CommandBase.FormatSuccessMessage()` → `MessageFormatter.FormatSuccessMessage()`
- `CommandBase.FormatErrorMessage()` → `MessageFormatter.FormatErrorMessage()`
- `CommandBase.ParseArguments()` → `ArgumentParser.ParseArguments()`
- `CommandBase.ValidateCampaignState()` → `CommandValidator.ValidateCampaignState()`
- `CommandBase.ValidateArgumentCount()` → `CommandValidator.ValidateArgumentCount()`
- `Cmd.Run()` remains `Cmd.Run()` (now in Execution namespace)

### Files Requiring Import Updates (31 total)

**Root Console:** CleanupCommands.cs, DevCommands.cs, GeneralCommands.cs, InfoCommands.cs, LoggerCommands.cs

**Query:** ClanQueryCommands.cs, CultureQueryCommands.cs, HeroQueryCommands.cs, ItemModifierQueryCommands.cs, ItemQueryCommands.cs, KingdomQueryCommands.cs, SettlementQueryCommands.cs, TroopQueryCommands.cs

**Clan:** ClanManagementCommands.cs, CreateClanCommand.cs, CreateMinorClan.cs, GenerateClansCommand.cs

**Hero:** HeroGenerationCommands.cs, HeroManagementCommands.cs

**Kingdom:** KingdomDiplomacyCommands.cs, KingdomGenerationCommands.cs, KingdomManagementCommands.cs

**Settlement:** FortificationManagementCommands.cs, SettlementManagementCommands.cs, VillageManagementCommands.cs

**Other:** BanditManagementCommands.cs, CaravanCreationCommands.cs, CaravanManagementCommands.cs, ItemManagementCommands.cs, TroopManagementCommands.cs

**Testing:** IntegrationTests.cs, NamePriorityTests.cs, StandardTests.cs, TestCommands.cs, TestRunner.cs

The refactoring backbone is complete and ready for you to update the command files with the new imports.