using System;
using System.Text;
using TaleWorlds.Library;

namespace Bannerlord.GameMaster.Console.Common.Execution
{
    /// <summary>
    /// Centralized exception handler for all console commands.
    /// Provides consistent error logging to RGL log files and formatted error messages for console display.
    /// </summary>
    public static class CommandErrorHandler
    {
        // MARK: Public Methods

        /// <summary>
        /// Handles an exception from a console command by logging full details to the RGL log
        /// and returning a formatted error message for console display.
        /// </summary>
        /// <param name="commandName">The name of the command that threw the exception</param>
        /// <param name="ex">The exception that was thrown</param>
        /// <returns>A formatted error message containing only the exception message for console display</returns>
        public static string HandleException(string commandName, Exception ex)
        {
            // Build detailed log message for RGL log file
            StringBuilder logBuilder = new();
            logBuilder.AppendLine("[BLGM] Command Error:");
            logBuilder.AppendLine($"Command: {commandName}");
            logBuilder.AppendLine($"Exception: {ex.Message}");
            logBuilder.AppendLine("Stack Trace:");
            logBuilder.AppendLine(ex.StackTrace);

            // Handle inner exceptions if present
            Exception innerEx = ex.InnerException;
            while (innerEx != null)
            {
                logBuilder.AppendLine();
                logBuilder.AppendLine($"Inner Exception: {innerEx.Message}");
                logBuilder.AppendLine("Inner Stack Trace:");
                logBuilder.AppendLine(innerEx.StackTrace);
                innerEx = innerEx.InnerException;
            }

            // Write full details to RGL log
            Debug.Print(logBuilder.ToString());

            // Return only the error message for console display (no command name or stack trace)
            return $"[BLGM] Command Error: {ex.Message}\n";
        }

        /// <summary>
        /// Handles an exception from a console command with additional context information.
        /// </summary>
        /// <param name="commandName">The name of the command that threw the exception</param>
        /// <param name="ex">The exception that was thrown</param>
        /// <param name="additionalContext">Additional context to include in the log</param>
        /// <returns>A formatted error message containing only the exception message for console display</returns>
        public static string HandleException(string commandName, Exception ex, string additionalContext)
        {
            // Build detailed log message for RGL log file
            StringBuilder logBuilder = new();
            logBuilder.AppendLine("[BLGM] Command Error:");
            logBuilder.AppendLine($"Command: {commandName}");
            logBuilder.AppendLine($"Context: {additionalContext}");
            logBuilder.AppendLine($"Exception: {ex.Message}");
            logBuilder.AppendLine("Stack Trace:");
            logBuilder.AppendLine(ex.StackTrace);

            // Handle inner exceptions if present
            Exception innerEx = ex.InnerException;
            while (innerEx != null)
            {
                logBuilder.AppendLine();
                logBuilder.AppendLine($"Inner Exception: {innerEx.Message}");
                logBuilder.AppendLine("Inner Stack Trace:");
                logBuilder.AppendLine(innerEx.StackTrace);
                innerEx = innerEx.InnerException;
            }

            // Write full details to RGL log
            Debug.Print(logBuilder.ToString());

            // Return only the error message for console display (no command name or stack trace)
            return $"[BLGM] Command Error: {ex.Message}\n";
        }
    }
}
